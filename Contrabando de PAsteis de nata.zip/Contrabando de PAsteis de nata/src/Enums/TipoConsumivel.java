package Enums;

public enum TipoConsumivel {
    VIDA,ATAQUE,DANOINSTANTANEO,DANOTEMPORARIO,DEFESA;
}