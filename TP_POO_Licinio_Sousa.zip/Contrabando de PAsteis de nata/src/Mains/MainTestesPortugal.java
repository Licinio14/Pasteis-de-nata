package Mains;

import Entidade.Heroi.ClassHeroi.Programador;
import Entidade.Heroi.Personagem;
import Itens.CriacoesItens.CriarArmasPrincipais;
import Jogo.Creditos;
import Jogo.Inicializacao;
import Jogo.Portugal;
import Loja.CriarMercado;
import Loja.Mercado;
import Tools.Tools;

public class MainTestesPortugal {
    public static void main(String[] args) throws InterruptedException {
        Creditos.start();
    }
}
