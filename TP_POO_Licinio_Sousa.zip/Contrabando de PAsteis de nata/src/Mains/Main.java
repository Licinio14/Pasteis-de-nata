package Mains;

import Jogo.Jogo;

public class Main {
    public static void main(String[] args) throws InterruptedException {

        Jogo.Iniciar();


    }
}
