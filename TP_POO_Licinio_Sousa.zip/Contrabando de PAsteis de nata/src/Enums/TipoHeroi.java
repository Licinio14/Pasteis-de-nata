package Enums;

public enum TipoHeroi {
    PROGRAMADOR,MILITAR,FUGITIVO,TODOS;
}
